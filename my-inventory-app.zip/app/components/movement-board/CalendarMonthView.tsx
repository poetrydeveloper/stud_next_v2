// components/movement-board/CalendarMonthView.tsx
'use client'

import { useEffect, useState } from 'react'
import { CalendarConfig } from './hooks/useCalendarConfig'
import { getStatusConfig } from './StatusIcons'

interface CalendarMonthViewProps {
  selectedMonth: Date
  productCode: string
  loading: boolean
  config: CalendarConfig
}

interface CalendarDay {
  date: Date
  isCurrentMonth: boolean
  units: {
    CLEAR: number
    CANDIDATE: number
    IN_REQUEST: number
    IN_STORE: number
    SOLD: number
  }
}

export default function CalendarMonthView({ 
  selectedMonth, 
  productCode, 
  loading,
  config 
}: CalendarMonthViewProps) {
  const [calendarDays, setCalendarDays] = useState<CalendarDay[]>([])

  useEffect(() => {
    generateCalendarData(selectedMonth)
  }, [selectedMonth, productCode])

  const generateCalendarData = (month: Date) => {
    const year = month.getFullYear()
    const monthIndex = month.getMonth()
    const firstDay = new Date(year, monthIndex, 1)
    const lastDay = new Date(year, monthIndex + 1, 0)
    
    const days: CalendarDay[] = []
    const startDay = new Date(firstDay)
    startDay.setDate(startDay.getDate() - firstDay.getDay())
    
    const totalDays = config.layout.gridColumns * config.layout.gridRows
    
    for (let i = 0; i < totalDays; i++) {
      const currentDate = new Date(startDay)
      currentDate.setDate(startDay.getDate() + i)
      
      days.push({
        date: new Date(currentDate),
        isCurrentMonth: currentDate.getMonth() === monthIndex,
        units: {
          CLEAR: Math.random() > 0.7 ? Math.floor(Math.random() * 3) : 0,
          CANDIDATE: Math.random() > 0.8 ? Math.floor(Math.random() * 2) : 0,
          IN_REQUEST: Math.random() > 0.9 ? Math.floor(Math.random() * 2) : 0,
          IN_STORE: Math.random() > 0.6 ? Math.floor(Math.random() * 4) : 0,
          SOLD: Math.random() > 0.5 ? Math.floor(Math.random() * 5) : 0
        }
      })
    }
    
    setCalendarDays(days)
  }

  const getStatusIconsForDay = (units: CalendarDay['units']) => {
    const activeStatuses = Object.entries(units)
      .filter(([_, count]) => count > 0)
      .map(([status, count]) => ({
        status,
        count,
        config: config.legend.iconMapping[status] || { symbol: '○', color: '#9ca3af', size: 12 }
      }))
      .slice(0, config.days.maxIconsPerDay)

    return activeStatuses
  }

  const getTotalUnitsForDay = (units: CalendarDay['units']) => {
    return Object.values(units).reduce((sum, count) => sum + count, 0)
  }

  const dayNames = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс']

  if (loading) {
    return (
      <div className="flex items-center justify-center h-16">
        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-500"></div>
      </div>
    )
  }

  const isVertical = config.layout.orientation === 'vertical'
  
  // Фиксируем классы grid вместо динамических
  const gridClass = isVertical 
    ? 'grid grid-cols-1 gap-0.5'
    : 'grid grid-cols-7 gap-0.5'

  return (
    <div className={`bg-white rounded ${isVertical ? 'overflow-y-auto max-h-80' : ''}`}>
      {/* Заголовки дней недели */}
      {config.layout.type !== 'vertical-timeline' && (
        <div className="grid grid-cols-7 gap-0.5 mb-1">
          {dayNames.map(day => (
            <div key={day} className={`text-center text-xs text-gray-500 py-0.5`}>
              {day}
            </div>
          ))}
        </div>
      )}

      {/* Дни календаря */}
      <div className={gridClass}>
        {calendarDays.map((day, index) => {
          const statusIcons = getStatusIconsForDay(day.units)
          const totalUnits = getTotalUnitsForDay(day.units)
          const isToday = day.date.toDateString() === new Date().toDateString()
          const hasOverflow = totalUnits > config.days.maxIconsPerDay

          return (
            <div
              key={index}
              className={`
                border rounded flex flex-col items-center justify-center
                text-xs
                ${
                  day.isCurrentMonth 
                    ? 'bg-white border-gray-200 text-gray-700' 
                    : 'bg-gray-50 border-gray-100 text-gray-400'
                }
                ${isToday ? `border-2 border-blue-300 bg-blue-50` : ''}
                ${config.days.compact ? 'p-0.5' : 'p-1'}
              `}
              style={{
                width: config.days.size.width,
                height: config.days.size.height,
                minWidth: config.days.size.width,
                minHeight: config.days.size.height
              }}
            >
              {/* Число */}
              <div className={`text-center leading-none ${config.days.compact ? 'mb-0.5' : 'mb-1'}`}>
                {day.date.getDate()}
              </div>

              {/* Иконки статусов */}
              <div className={`flex justify-center items-center gap-0.5 w-full min-h-3`}>
                {config.days.overflowBehavior === 'number' && hasOverflow ? (
                  <div className="text-xs font-medium text-gray-600 bg-gray-100 px-1 rounded">
                    +{totalUnits}
                  </div>
                ) : (
                  <>
                    {statusIcons.map((item, idx) => (
                      <div
                        key={idx}
                        className="flex items-center justify-center"
                        style={{ 
                          fontSize: item.config.size,
                          color: item.config.color
                        }}
                        title={`${getStatusConfig(item.status).label}: ${item.count}`}
                      >
                        {item.config.symbol}
                        {config.days.overflowBehavior === 'stack' && item.count > 1 && (
                          <span className="text-[8px] ml-0.5">{item.count}</span>
                        )}
                      </div>
                    ))}
                  </>
                )}
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}