// components/movement-board/CalendarTimeline.tsx
'use client'

import { useState } from 'react'
import CalendarNavigation from './CalendarNavigation'
import CalendarMonthView from './CalendarMonthView'
import ConfigSelector from './ConfigSelector'
import { CalendarConfig } from './types/CalendarConfig'

interface CalendarTimelineProps {
  product: any
  selectedMonth: Date
  onMonthChange: (date: Date) => void
  config: CalendarConfig
  onConfigChange?: (preset: string) => void
}

export default function CalendarTimeline({ 
  product, 
  selectedMonth, 
  onMonthChange,
  config,
  onConfigChange
}: CalendarTimelineProps) {
  const [loading, setLoading] = useState(false)
  
  const handleMonthChange = async (newDate: Date) => {
    setLoading(true)
    onMonthChange(newDate)
    setTimeout(() => setLoading(false), 300)
  }

  return (
    <div className="bg-white border border-gray-200 rounded p-2">
      <div className="flex items-center justify-between mb-2">
        <h3 className="font-semibold text-gray-800 text-xs">Календарь движений</h3>
        <ConfigSelector onConfigChange={onConfigChange} />
      </div>
      
      <CalendarNavigation 
        selectedMonth={selectedMonth}
        onMonthChange={handleMonthChange}
        loading={loading}
        config={config}
      />
      
      <CalendarMonthView 
        selectedMonth={selectedMonth}
        productCode={product.code}
        loading={loading}
        config={config}
      />

      {/* Легенда статусов */}
      {config.legend.position !== 'hidden' && (
        <div className={`mt-2 pt-2 border-t border-gray-100 ${
          config.legend.position === 'bottom' ? 'flex flex-wrap gap-1 justify-center' : ''
        }`}>
          {Object.entries(config.legend.iconMapping).map(([status, iconConfig]) => (
            <div
              key={status}
              className={`flex items-center gap-1 ${config.legend.compact ? 'text-xs' : 'text-sm'} ${
                config.legend.position === 'bottom' ? 'px-2 py-1' : 'mb-1'
              }`}
            >
              <span style={{ color: iconConfig.color, fontSize: iconConfig.size }}>
                {iconConfig.symbol}
              </span>
              <span className="text-gray-600">
                {getStatusConfig(status).label}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

// Вспомогательная функция для получения конфига статуса
function getStatusConfig(status: string) {
  const configs: Record<string, { label: string }> = {
    CLEAR: { label: 'Создан' },
    CANDIDATE: { label: 'Кандидат' },
    IN_REQUEST: { label: 'В заявке' },
    IN_STORE: { label: 'В магазине' },
    SOLD: { label: 'Продан' }
  }
  return configs[status] || { label: status }
}