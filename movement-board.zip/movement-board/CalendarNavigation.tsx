// components/movement-board/CalendarNavigation.tsx
'use client'

import { CalendarConfig } from './hooks/useCalendarConfig'

interface CalendarNavigationProps {
  selectedMonth: Date
  onMonthChange: (date: Date) => void
  loading: boolean
  config: CalendarConfig
}

export default function CalendarNavigation({ 
  selectedMonth, 
  onMonthChange, 
  loading,
  config 
}: CalendarNavigationProps) {
  
  const navigateMonth = (direction: 'prev' | 'next') => {
    const newDate = new Date(selectedMonth)
    if (config.layout.type === 'vertical-timeline') {
      newDate.setMonth(newDate.getMonth() + (direction === 'prev' ? -config.layout.visibleMonths : config.layout.visibleMonths))
    } else {
      newDate.setMonth(newDate.getMonth() + (direction === 'prev' ? -1 : 1))
    }
    onMonthChange(newDate)
  }

  const monthNames = ['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь']
  const shortMonthNames = ['Янв', 'Фев', 'Мар', 'Апр', 'Май', 'Июн', 'Июл', 'Авг', 'Сен', 'Окт', 'Ноя', 'Дек']

  const getMonthLabel = () => {
    if (config.layout.type === 'vertical-timeline') {
      const endMonth = new Date(selectedMonth)
      endMonth.setMonth(endMonth.getMonth() + config.layout.visibleMonths - 1)
      
      return (
        <div className="text-xs font-semibold text-gray-800 text-center">
          <div>{shortMonthNames[selectedMonth.getMonth()]} {selectedMonth.getFullYear()}</div>
          <div className="text-gray-500">-</div>
          <div>{shortMonthNames[endMonth.getMonth()]} {endMonth.getFullYear()}</div>
        </div>
      )
    }
    
    return (
      <div className="text-sm font-semibold text-gray-800">
        <span>{config.days.compact ? shortMonthNames[selectedMonth.getMonth()] : monthNames[selectedMonth.getMonth()]}</span>
        <span> {selectedMonth.getFullYear()}</span>
        {loading && <span className="text-xs text-gray-500 ml-1">...</span>}
      </div>
    )
  }

  return (
    <div className={`flex items-center justify-between mb-2 ${config.layout.type === 'vertical-timeline' ? 'flex-col gap-1' : ''}`}>
      <button
        onClick={() => navigateMonth('prev')}
        disabled={loading}
        className={`p-1 hover:bg-gray-100 rounded text-sm disabled:opacity-50 ${config.days.compact ? 'text-xs' : ''}`}
        title="Предыдущий месяц"
      >
        ←
      </button>
      
      {getMonthLabel()}
      
      <button
        onClick={() => navigateMonth('next')}
        disabled={loading}
        className={`p-1 hover:bg-gray-100 rounded text-sm disabled:opacity-50 ${config.days.compact ? 'text-xs' : ''}`}
        title="Следующий месяц"
      >
        →
      </button>
    </div>
  )
}