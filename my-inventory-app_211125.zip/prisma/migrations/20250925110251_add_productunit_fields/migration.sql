-- AlterEnum
ALTER TYPE "public"."ProductUnitCardStatus" ADD VALUE 'CLEAR';
