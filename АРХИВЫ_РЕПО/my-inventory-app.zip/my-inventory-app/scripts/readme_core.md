# Экспорт текущего ядра
npm run core:export my-store

# Импорт ядра (с очисткой старых данных)
npm run core:import my-store-2024-10-14T10-30-00Z.json --clear

# Просмотр файлов ядра
npm run core:list

# Очистка ядра данных
npm run core:clear