// app/inventory/visual/page.tsx
import InventoryVisual from '../../components/inventory/InventoryVisual';

export default function VisualPage() {
  return <InventoryVisual />;
}