// app/analytics/page.tsx
import SalesAnalytics from '../components/analytics/SalesAnalytics';

export default function AnalyticsPage() {
  return <SalesAnalytics />;
}