// legend content placeholder
