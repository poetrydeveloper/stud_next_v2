// calendar content placeholder
