// adapter content placeholder
