// day content placeholder
