// lines content placeholder
